#!/usr/bin/env python
# coding: utf-8

# # 机器学习预测mvp

# In[1]:


import numpy as np
import pandas as pd


# In[2]:


stats = pd.read_csv("player_mvp_stats.csv",index_col=0)
stats.head()


# ## 1.预处理

# ### 1.指定预测年份

# In[3]:


pred_year = 2019


# ### 2.填补缺失值

# In[4]:


stats["GB"] = stats["GB"].str.replace("—","0")
stats["GB"] = pd.to_numeric(stats["GB"])


# In[5]:


stats["GB"].dtype


# In[6]:


stats = stats.apply(pd.to_numeric, errors='ignore')


# In[7]:


stats = stats.fillna(0)


# ### 3.选择predictor

# In[8]:


stats.columns


# In[9]:


predictors = ["Age", "G", "GS", "MP", "FG", "FGA", 'FG%', '3P', '3PA'
              , '3P%', '2P', '2PA', '2P%', 'eFG%', 'FT', 'FTA', 'FT%'
              , 'ORB', 'DRB', 'TRB', 'AST', 'STL', 'BLK', 'TOV', 'PF', 'PTS', 'W', 'L', 'W/L%',
       'GB', 'PS/G', 'PA/G', 'SRS','Pos']


# #### 1.创建哑变量
# 1.发现此前模型在预测时，容易给后卫更高的权重
#   因此加入 "Pos"(Postion)变量，削弱这一影响
#
# 2.若将球队作为哑变量，维数增加过多
#   经过比较，发现所在球队对mvp归属影响不大，因此略去
# In[10]:


pd.get_dummies(stats['Pos'],prefix='Pos')


# In[11]:


dummy_pos = pd.get_dummies(stats['Pos'],prefix='Pos')
dummy_pos.columns


# In[12]:


predictors.remove("Pos")


# In[13]:


predictors_and_dum = predictors + dummy_pos.columns.tolist()


# In[14]:


predictors_and_dum


# In[15]:


stats_and_dum = stats.join(dummy_pos)
stats_and_dum.head()


# # #### 2.加入ratio变量
# 加入后效果不佳
# 可直接注释，不影响后续代码运行
# # In[16]:


stats_and_dum[["PTS_R", "AST_R", "STL_R", "BLK_R", "3P_R"]] = stats_and_dum.groupby("Year")[["PTS", "AST", "STL", "BLK", "3P"]].apply(lambda x: x/x.mean())


# In[17]:


new_predictor = ["PTS_R", "AST_R", "STL_R", "BLK_R", "3P_R"]
predictors_and_dum += new_predictor


# #### 3.划分 train/test

# In[18]:


train = stats_and_dum[~(stats_and_dum["Year"] == pred_year)]
test = stats_and_dum[stats_and_dum["Year"] == pred_year]


# In[19]:


train.head()


# In[20]:


train_x = train[predictors_and_dum]
train_y = train["Share"]

test_x = test[predictors_and_dum]
test_y = test["Share"]


# ## 2.机器学习预测

# In[21]:


from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
import xgboost as xgb

from sklearn.metrics import mean_squared_error


# ### 1.定义工具

# In[22]:


## 展示预测结果
def show_pre_table(mvp_prediction):
    pd_mvp_pred = pd.DataFrame(mvp_prediction, columns=["predictions"], index=test_y.index)
    combinations = pd.concat([test[["Player","Share"]],pd_mvp_pred], axis=1)
    
    actual = combinations.sort_values("Share", ascending=False)
    predicted = combinations.sort_values("predictions", ascending=False)
    actual["Rk"] = list(range(1,actual.shape[0]+1))
    predicted["Predicted_Rk"] = list(range(1,predicted.shape[0]+1))

    pred_table = actual.merge(predicted, on="Player")
    
    #删除多余的列并修改列名
    del pred_table["Share_y"]
    del pred_table["predictions_y"]
    pred_table.rename(columns={'Share_x':'Share', 'predictions_x':'predictions'}, inplace=True)
    
    pred_table["Rk_diff"] = pred_table["Rk"] - pred_table["Predicted_Rk"]
    
    return pred_table   


# In[23]:


'''
展示预测误差
1.不指定topn时，计算全部误差
2.指定topn时，计算前实际前十的误差
'''
def show_mse_error(pred_table,topn = 0):
    if topn == 0:
        mse = mean_squared_error(pred_table["Share"], pred_table["predictions"])
    else:
        topN = pred_table.iloc[:10,:]
        mse = mean_squared_error(topN["Share"], topN["predictions"])
        
    return mse


# ### 2.使用岭回归预测

# In[24]:


reg = Ridge(alpha=0.1)
reg.fit(train_x, train_y)


# In[25]:


mvp_pred_reg = reg.predict(test_x)


# In[26]:


reg_tb = show_pre_table(mvp_pred_reg)
reg_tb.head(10)


# In[27]:


reg_tb["Share"].value_counts()

# 大多数球员没有mvp评分，在评估/训练时可尝试删去
# # In[28]:


show_mse_error(reg_tb,10)

# 模型效果不理想，需进一步改进
# # ### 3.使用随机森林预测

# In[29]:


rf = RandomForestRegressor(n_estimators=300, random_state=1, min_samples_split=5)
rf.fit(train_x,train_y)


# In[30]:


mvp_pred_rf = rf.predict(test_x)


# In[31]:


rf_tb = show_pre_table(mvp_pred_rf)
rf_tb.head(10)


# In[32]:


show_mse_error(rf_tb)


# #### 1.变量重要性

# In[33]:


importance_rf = pd.Series(rf.feature_importances_, index=test_x.columns)
sorted_importance_rf = importance_rf.sort_values()

sorted_importance_rf.plot(kind="barh",color='lightgreen',figsize=([12,12]))


# #### 2.GridCVSearch

# In[34]:


from sklearn.model_selection import GridSearchCV


# In[35]:


rf_grid = RandomForestRegressor()

params_dt = {
    'max_depth': [3,4,5,6],
    'min_samples_leaf' : [0.04, 0.06, 0.08],
    'max_features' : [0.2, 0.4, 0.6, 0.8]
}


# In[36]:


grid_dt = GridSearchCV(estimator=rf_grid,
                      param_grid=params_dt,
                      scoring="neg_mean_squared_error",
                      cv=5,
                      n_jobs=-1)


# In[37]:


grid_dt.fit(train_x,train_y)


# In[38]:


grid_dt.best_params_


# In[39]:


grid_rf_mvp =  grid_dt.predict(test_x)
grid_rf_tb = show_pre_table(grid_rf_mvp)
grid_rf_tb.head(20)


# In[40]:


show_mse_error(grid_rf_tb)


# ### 4.使用xgboost进行预测

# #### 1.加入权重

# In[41]:


reg_tb["Share"].value_counts()

# 大多数球员没有mvp评分
# 因为重点是预测准确mvp归属，评分为0的球员重要性更低
# 因此可以尝试给训练集中有评分的球员更高的权重，提高有可能获得mvp球员的预测准确率
# # In[42]:


weight_train_x = train_y.apply(lambda x: 1.5 if (x!=0) else 1)
weight_train_x = np.array(weight_train_x)


# #### 2.用sklearn接口预测

# In[43]:


# 加权重效果不好，也可能权重要设置更优的值
# xgb_weight = XGBRegressor().fit(train_x, train_y,sample_weight = weight_train_x)
xgb_weight = XGBRegressor().fit(train_x, train_y)


# In[44]:


xgb_pred = xgb_weight .predict(test_x)


# In[45]:


xg_tb = show_pre_table(xgb_pred)
xg_tb.head(10)


# In[46]:


show_mse_error(xg_tb)


# #### 3.用C接口预测

# In[47]:


dtrain = xgb.DMatrix(train_x, train_y)
dtest = xgb.DMatrix(test_x, test_y)


# In[48]:


params = {
    'objective' : 'multi:softprob',  #类似于sigmod,可以将多分类的预测值映射到0到1之间，通过softmax函数解决多分类问题
    #'objective' : 'multi:softprob', #类似于predict_prob，给出每个样本在每个类别下下的预测概率
    'num_class' : 3,   # 必须告知字典，当前数据集里Y标签的种类有多少
    'eval_metric' : ['merror', 'mlogloss'],
    'eta' : 0.1,       # 学习率
    'max_depth' : 5,   # 树的最大深度
    'gamma' : 0,#后剪枝的过程,0到正无穷, 默认0，尝试0, 1，5，10，100
    'min_child_weight':1,#叶子节点权重分数的下界
}


# In[49]:


watchlist = [(dtrain, 'train'),(dtest, 'test')]
model = xgb.train(params, dtrain, 1000, 
                  watchlist, 
                  early_stopping_rounds = 10,
                  verbose_eval = False
                 )


# In[50]:


Y_train_pred = model.predict(dtrain)
Y_test_pred = model.predict(dtest)  # 由于设定的是softmax，所以给出的结果直接是label, 可以尝试改成softprob


# In[51]:


Y_test_pred


# In[ ]:





# In[ ]:




