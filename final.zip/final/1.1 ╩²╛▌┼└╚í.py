#!/usr/bin/env python
# coding: utf-8

# In[1]:


import requests 
import os 
import shutil 
import pandas as pd


# In[2]:


from bs4 import BeautifulSoup


# In[3]:


from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time


# ## 历届MVP数据

# ### 可修改字段：年份

# In[9]:


#注意左闭右开
years = list(range(1992,2021))


# In[35]:


url_start = "https://www.basketball-reference.com/awards/awards_{}.html"
for year in years:
    url = url_start.format(year)
    data = requests.get(url)
    with open("mvp/{}.html".format(year),"w+",encoding='utf-8') as f:
        f.write(data.text)
    time.sleep(1)


# In[11]:


dfs = []
for year in years:
    page = open("mvp/{}.html".format(year),encoding='utf-8')
    soup = BeautifulSoup(page,'lxml')
    # soup.find('tr', class_="over_header")
    mvp_table = soup.find_all(id="mvp")[0]
    mvp_df = pd.read_html(str(mvp_table))[0]
    mvp_df["Year"] = year
    dfs.append(mvp_df)
    page.close()


# In[12]:


mvps = pd.concat(dfs)
mvps.info()


# In[13]:


mvps.head(20)


# In[14]:


mvps.to_csv("mvps.csv")


# ## 所有球员数据

# ### 可修改字段：webdriver 地址

# In[5]:


driver = webdriver.Chrome(executable_path='C:/Program Files/Google/Chrome/Application/chromedriver.exe')


# In[6]:


player_stats_url = "https://www.basketball-reference.com/leagues/NBA_{}_per_game.html"


# In[80]:


for year in years:
    url = player_stats_url.format(year)
    
    data = requests.get(url)
    
    with open("player/{}.html".format(year), "w+", encoding='utf-8') as f:
        f.write(data.text)
    
    time.sleep(1)


# In[7]:


for year in years:
    url = player_stats_url.format(year)
    
    driver.get(url)
    driver.execute_script("window.scrollTo(1,10000)")
    time.sleep(1)
    
    with open("player/{}.html".format(year), "w+", encoding='utf-8') as f:
        f.write(driver.page_source)


# In[10]:


dfs2 = []
for year in years:
    page = open("player/{}.html".format(year),encoding='utf-8')
    soup = BeautifulSoup(page,'lxml')
    # soup.find('tr', class_="over_header")
    player_table = soup.find_all(id="per_game_stats")[0]
    player_df = pd.read_html(str(player_table))[0]
    player_df["Year"] = year
    dfs2.append(player_df)
    page.close()


# In[11]:


players = pd.concat(dfs2)


# In[15]:


players.head()


# In[13]:


players.to_csv("players.csv")


# ## 球队数据

# In[83]:


team_stats_url = "https://www.basketball-reference.com/leagues/NBA_{}_standings.html"


# In[85]:


for year in years:
    url = team_stats_url.format(year)
    
    data = requests.get(url)
    
    with open("team/{}.html".format(year), "w+", encoding='utf-8') as f:
        f.write(data.text)
        
    time.sleep(1)


# In[86]:


dfs = []
for year in years:
    with open("team/{}.html".format(year)) as f:
        page = f.read()
    
    soup = BeautifulSoup(page, 'html.parser')
    # soup.find('tr', class_="thead").decompose()
    e_table = soup.find_all(id="divs_standings_E")[0]
    e_df = pd.read_html(str(e_table))[0]
    e_df["Year"] = year
    e_df["Team"] = e_df["Eastern Conference"]
    del e_df["Eastern Conference"]
    dfs.append(e_df)
    
    w_table = soup.find_all(id="divs_standings_W")[0]
    w_df = pd.read_html(str(w_table))[0]
    w_df["Year"] = year
    w_df["Team"] = w_df["Western Conference"]
    del w_df["Western Conference"]
    dfs.append(w_df)


# In[87]:


teams = pd.concat(dfs)


# In[89]:


teams.head()


# In[90]:


teams.to_csv("teams.csv")


# In[ ]:





# In[ ]:




