#!/usr/bin/env python
# coding: utf-8

# # 数据清洗

# In[1]:


import numpy as np
import pandas as pd


# ## mvp球员数据清洗

# In[2]:


mvps = pd.read_csv("mvps.csv",header = 1)


# In[3]:


mvps.head()


# In[4]:


mvps.rename(columns={'Unnamed: 21':'Year'},inplace=True)
mvps.head()


# In[5]:


mvps = mvps[["Player", "Year", "Pts Won", "Pts Max", "Share"]]
mvps.head()


# ## 球员数据清洗

# In[6]:


players = pd.read_csv("players.csv")
players.head()


# In[7]:


del players["Unnamed: 0"]
del players["Rk"]


# In[8]:


players.head()


# In[9]:


def single_team(df):
    if df.shape[0]==1:
        return df
    else:
        row = df[df["Tm"]=="TOT"]
        row["Tm"] = df.iloc[-1,:]["Tm"]
        return row


# In[10]:


players = players.groupby(["Player", "Year"]).apply(single_team)


# In[11]:


players


# In[12]:


players.index = players.index.droplevel()


# In[13]:


players


# In[14]:


players.index = players.index.droplevel()
players


# ## 连接球员数据和MVP投票数据

# In[15]:


## 去掉player前的*，便于后续连接
players["Player"] = players["Player"].str.replace("*","")


# In[16]:


combined = players.merge(mvps, how="outer", on=["Player", "Year"])
combined.head()


# In[17]:


combined[["Pts Won", "Pts Max", "Share"]] = combined[["Pts Won", "Pts Max", "Share"]].fillna(0)
combined.head()


# ## 球队数据清洗

# In[18]:


teams = pd.read_csv("teams.csv")
teams.head()


# In[19]:


del teams["Unnamed: 0"]


# In[20]:


teams["Team"] = teams["Team"].str.replace("*", "", regex=False)


# In[21]:


teams = teams[~teams["W"].str.contains("Division")].copy()
teams.head()


# ### 导入nickname

# In[22]:


nicknames = {'ATL': 'Atlanta Hawks',
 'BRK': 'Brooklyn Nets',
 'BKN': 'Brooklyn Nets',
 'BOS': 'Boston Celtics',
 'CHA': 'Charlotte Bobcats',
 'CHH': 'Charlotte Hornets',
 'CHO': 'Charlotte Hornets',
 'CHI': 'Chicago Bulls',
 'CLE': 'Cleveland Cavaliers',
 'DAL': 'Dallas Mavericks',
 'DEN': 'Denver Nuggets',
 'DET': 'Detroit Pistons',
 'GSW': 'Golden State Warriors',
 'HOU': 'Houston Rockets',
 'IND': 'Indiana Pacers',
 'LAC': 'Los Angeles Clippers',
 'LAL': 'Los Angeles Lakers',
 'MEM': 'Memphis Grizzlies',
 'MIA': 'Miami Heat',
 'MIL': 'Milwaukee Bucks',
 'MIN': 'Minnesota Timberwolves',
 'NJN': 'New Jersey Nets',
 'NOH': 'New Orleans Hornets',
 'NOP': 'New Orleans Pelicans',
 'NOK': 'New Orleans/Oklahoma City Hornets',
 'NYK': 'New York Knicks',
 'OKC': 'Oklahoma City Thunder',
 'ORL': 'Orlando Magic',
 'PHI': 'Philadelphia 76ers',
 'PHX': 'Phoenix Suns',
 'PHO': 'Phoenix Suns',
 'POR': 'Portland Trail Blazers',
 'SEA': 'Seattle SuperSonics',
 'SAC': 'Sacramento Kings',
 'SAS': 'San Antonio Spurs',
 'TOR': 'Toronto Raptors',
 'UTA': 'Utah Jazz',
 'VAN': 'Vancouver Grizzlies',
 'WAS': 'Washington Wizards',
 'WSB': 'Washington Bullets'}


# In[23]:


combined["Team"] = combined["Tm"].map(nicknames)


# In[24]:


combined.head()


# ## 生成最终数据

# In[25]:


final_df = combined.merge(teams,how="outer",on=["Team","Year"])
final_df.head()


# In[26]:


final_df.dtypes


# In[27]:

# 此处需要取消注释
# final_df.to_csv("player_mvp_stats.csv")

print("docker dispose successful")